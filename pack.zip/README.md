# The Football Pulse – installation depuis le téléphone

1. Firebase : créer un projet, ajouter une app Android (package : com.footballpulse.app), télécharger google-services.json, puis générer une clé privée de compte de service (JSON).
2. GitHub : créer un dépôt PUBLIC, envoyer pack.zip (Add file > Upload files), puis créer le fichier .github/workflows/app.yml (Add file > Create new file) et y coller le contenu de app.yml.
3. Settings > Secrets and variables > Actions : ANTHROPIC_API_KEY, GOOGLE_SERVICES_JSON (contenu de google-services.json), FIREBASE_SERVICE_ACCOUNT (contenu de la clé JSON).
4. Actions > Football Pulse > Run workflow : choisir setup, puis fetch, puis build.
5. Releases > télécharger app-debug.apk et l'installer.
