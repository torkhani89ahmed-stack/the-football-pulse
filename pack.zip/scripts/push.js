import fs from 'fs';
const key = process.env.FIREBASE_SERVICE_ACCOUNT;
const file = '/tmp/new.json';
if (!key || !fs.existsSync(file)) { console.log('No push to send'); process.exit(0); }
const posts = JSON.parse(fs.readFileSync(file));
if (!posts.length) process.exit(0);
const admin = (await import('firebase-admin')).default;
admin.initializeApp({ credential: admin.credential.cert(JSON.parse(key)) });
for (const p of posts.slice(0, 5)) {
  await admin.messaging().send({
    topic: 'news',
    notification: { title: 'New post ready to share ⚽', body: p.title },
    android: { priority: 'high' }
  });
}
console.log('Sent', Math.min(posts.length, 5), 'notifications');
