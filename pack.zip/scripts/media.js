import { execFileSync } from 'child_process';
import { createHash } from 'crypto';
import fs from 'fs';
const FONT = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';
const FORMATS = {
  video: { w: 1080, h: 1080, logo: 300, ly: 70, ty: 470, fs: 58, step: 85, wrap: 26, bh: 1020 },
  reel: { w: 1080, h: 1920, logo: 380, ly: 330, ty: 860, fs: 64, step: 95, wrap: 22, bh: 1860 }
};
function wrap(t, n) {
  const out = []; let l = '';
  for (const w of t.split(' ')) {
    if ((l + ' ' + w).trim().length > n) { out.push(l); l = w; } else l = (l + ' ' + w).trim();
  }
  out.push(l);
  return out.slice(0, 7);
}
function filter(f, title, tmp) {
  const dt = wrap(title, f.wrap).map((l, i) => {
    fs.writeFileSync(`${tmp}/${f.w}_${i}.txt`, l);
    return `drawtext=fontfile=${FONT}:textfile=${tmp}/${f.w}_${i}.txt:fontcolor=0xf5d77a:fontsize=${f.fs}:x=(w-text_w)/2:y=${f.ty + i * f.step}:alpha='min(max((t-${1 + i * 0.4})/0.5,0),1)'`;
  }).join(',');
  return `[1:v]scale=${f.logo}:${f.logo},format=rgba,fade=t=in:st=0:d=1:alpha=1[l];[0:v][l]overlay=${(f.w - f.logo) / 2}:${f.ly},drawbox=x=30:y=30:w=1020:h=${f.bh}:color=0xd4af37:t=12,${dt}`;
}
const run = (f, title, tmp, out, extra) => execFileSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', `color=c=0x0a0a0a:s=${f.w}x${f.h}:d=7:r=30`, '-loop', '1', '-i', 'www/logo.png', '-filter_complex', filter(f, title, tmp), ...extra, out], { stdio: 'ignore' });
export function makeMedia(id, title) {
  fs.mkdirSync('data/media', { recursive: true });
  const tmp = fs.mkdtempSync('/tmp/m');
  const n = 'data/media/' + createHash('md5').update(id).digest('hex').slice(0, 12);
  run(FORMATS.video, title, tmp, `${n}.mp4`, ['-t', '7', '-pix_fmt', 'yuv420p']);
  run(FORMATS.video, title, tmp, `${n}.png`, ['-ss', '6.5', '-frames:v', '1']);
  run(FORMATS.reel, title, tmp, `${n}_reel.mp4`, ['-t', '7', '-pix_fmt', 'yuv420p']);
  return { image: `${n}.png`, video: `${n}.mp4`, reel: `${n}_reel.mp4` };
}
