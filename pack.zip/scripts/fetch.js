import fs from 'fs';
import { makeMedia } from './media.js';
const sources = JSON.parse(fs.readFileSync('sources.json'));
const file = 'data/posts.json';
const posts = JSON.parse(fs.readFileSync(file));
const known = new Set(posts.map(p => p.id));
const tag = (s, t) => {
  const m = s.match(new RegExp(`<${t}[^>]*>([\\s\\S]*?)</${t}>`));
  return m ? m[1].replace(/<!\[CDATA\[|\]\]>/g, '').replace(/<[^>]+>/g, '').trim() : '';
};
async function write(a) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'claude-haiku-5-5', max_tokens: 300, messages: [{ role: 'user', content:
      `Write an engaging Facebook post in English (max 60 words, 1-2 emojis, 2-3 hashtags) for the football page "The Football Pulse". Use your own words, based only on this news. End with "Source: ${a.source}".\nTitle: ${a.title}\nSummary: ${a.summary}` }] })
  });
  const j = await r.json();
  return j.content?.[0]?.text;
}
let added = 0;
const fresh = [];
for (const s of sources) {
  try {
    const xml = await (await fetch(s.url)).text();
    for (const it of xml.split(/<item[ >]/).slice(1, 6)) {
      const link = tag(it, 'link') || tag(it, 'guid');
      if (!link || known.has(link) || added >= 10) continue;
      const a = { id: link, title: tag(it, 'title'), summary: tag(it, 'description').slice(0, 500), source: s.name };
      const text = await write(a);
      if (!text) continue;
      let media = {};
      try { media = makeMedia(link, a.title); } catch (e) { console.error('media', e.message); }
      posts.unshift({ id: link, title: a.title, source: s.name, date: new Date().toISOString(), text, ...media });
      fresh.push(posts[0]);
      known.add(link); added++;
    }
  } catch (e) { console.error(s.name, e.message); }
}
for (const p of posts.slice(30)) for (const m of [p.image, p.video, p.reel]) if (m) fs.rmSync(m, { force: true });
fs.writeFileSync(file, JSON.stringify(posts.slice(0, 30), null, 1));
fs.writeFileSync('/tmp/new.json', JSON.stringify(fresh));
